
/**
 * Repräsentiert den Mitarbeiter
 * 
 * @author Lennart 
 * @version 1.0
 */

public class Mitarbeiter
{

    private String name="", vorname="", abteilung="", geburtsdatum="";
    private int personalnummer=0;
    public Mitarbeiter(String name, String vorname, int personalnummer, String geburtsdatum, String abteilung)
    {
        this.name=name;
        this.vorname=vorname;
        this.personalnummer=personalnummer;
        this.geburtsdatum=geburtsdatum;
        this.abteilung=abteilung;
    }
    
    public void setName(String name) { this.name=name; }
    public void setVorname(String vorname) { this.vorname=vorname; }
    public void setPersonalnummer(int personalnummer) { this.personalnummer=personalnummer; }
    public void setGeburtsdatum(String geburtsdatum) {  this.geburtsdatum=geburtsdatum; }
    public void setAbteilung(String abteilung) {  this.abteilung=abteilung; }
    
    public String getName() {return name;}
    public String getVorname() {return vorname;}
    public int getPersonalnummer() {return personalnummer;}
    public String getGeburtsdatum() {return geburtsdatum;}
    public String getAbteilung() {return abteilung;}
    
    public void detailAusgabe() {
        System.out.println("Name: "+name+", Vorname: "+vorname+", Personalnummer: "+personalnummer+", Geburtsdatum: "+geburtsdatum+", Abteilung: "+abteilung);
    }

}
