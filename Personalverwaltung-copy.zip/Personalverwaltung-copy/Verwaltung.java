
/**
 * Repräsentiert mehrer Mitarbeiter
 * 
 * @author Lennart Protte
 * @version 1.0
 */
public class Verwaltung
{
    Mitarbeiter[] mitarbeiter;
    public Verwaltung(int anzahlMitarbeiter)
    {
        if(anzahlMitarbeiter>0) {
        mitarbeiter = new Mitarbeiter[anzahlMitarbeiter];
        }
    }
    
    public void neuerMitarbeiter(int position, String name, String vorname, int personalnummer, String geburtsdatum, String abteilung) {
        if(position>=0&&position<=mitarbeiter.length) {
            mitarbeiter[position]=new Mitarbeiter(name, vorname, personalnummer, geburtsdatum, abteilung);
        }
    }
    
    public void schreibeMitarbeiterdaten(int position) {
        if(position>=0&&position<=mitarbeiter.length) {
            if(mitarbeiter[position]!=null) {
                mitarbeiter[position].detailAusgabe();
            } else {
                System.out.println("Es wurde an der ausgewählten Stelle noch kein Mitarbeiter eingetragen.");
            }
        }
    }
    
    public void sucheMitarbeiterMitName(String name) {
        for(int i=0; i<mitarbeiter.length; i++) {
            if(mitarbeiter[i]!=null && mitarbeiter[i].getName().equals(name)) {
                mitarbeiter[i].detailAusgabe();
            }    
        }
    }
    
    public void schreibeAbteilung(String abteilung) {
        int anzahlMitarbeiter=0;
        for(int i=0; i<mitarbeiter.length; i++) {
            if(mitarbeiter[i]!=null && mitarbeiter[i].getAbteilung().equals(abteilung)) {
                anzahlMitarbeiter++;
            }
                
        }
        System.out.println("Es arbeiten "+anzahlMitarbeiter+" Mitarbeiter in der Abteilung");
    }
    
    public void ordneMitarbeiterZuAbteilung(int personalnummer, String abteilung) {
        boolean erfolgreich=false;
        for(int i=0; i<mitarbeiter.length; i++) {
            if(mitarbeiter[i]!=null && mitarbeiter[i].getPersonalnummer()==personalnummer) {
                mitarbeiter[i].setAbteilung(abteilung);
                erfolgreich=true;
            } 
        }
        if(erfolgreich) {
            System.out.println("Die Zuteilung war erfolgreich");
        } else {
            System.out.println("Die Zuteilung war nicht erfolgreich");
        }
    }
}
